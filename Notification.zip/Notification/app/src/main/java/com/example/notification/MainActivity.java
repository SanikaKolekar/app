package com.example.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.core.content.res.ResourcesCompat;

public class MainActivity extends AppCompatActivity {
    private static final String CHANNEL_ID="MY CHANNEL";
    private static final int REQUEST_CODE=100;
    private static final int NOTIFICATION_ID=100;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Notification notification;
        NotificationManager nm= (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Drawable drawable=ResourcesCompat.getDrawable(getResources(),R.drawable.img,null);
        BitmapDrawable bitmapDrawable= (BitmapDrawable) drawable;
        Bitmap largeIcon= bitmapDrawable.getBitmap();
        Intent notify=new Intent(getApplicationContext(), MainActivity.class);
        notify.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ip=PendingIntent.getActivity(this,REQUEST_CODE,notify,PendingIntent.FLAG_UPDATE_CURRENT);
        if(android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
        {
            notification=new Notification.Builder(this)
                    .setLargeIcon(largeIcon)
                    .setChannelId(CHANNEL_ID)
                    .setContentText("New message")
                    .setSmallIcon(R.drawable.img)
                    .setSubText("Message from Arpita")
                    .build();
            nm.createNotificationChannel(new NotificationChannel(CHANNEL_ID,"My channel",NotificationManager.IMPORTANCE_HIGH));

        }
        else
        {
            notification=new Notification.Builder(this)
                    .setLargeIcon(largeIcon)
                    .setContentText("New message")
                    .setSmallIcon(R.drawable.img)
                    .setSubText("Message from Arpita")
                    .build();

        }
        nm.notify(NOTIFICATION_ID,notification);
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.homemenu, menu);
        return true;
    }

    public  void start(View view)
    {
        Intent intent=new Intent(getApplicationContext(), MainActivity2.class);
        startActivity(intent);
    }
}