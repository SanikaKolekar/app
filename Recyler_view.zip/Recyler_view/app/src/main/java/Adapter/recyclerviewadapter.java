package Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.recyler_view.R;
import model.receipemodel;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

public class recyclerviewadapter extends RecyclerView.Adapter<recyclerviewadapter.viewHolder>{

    Context context;
    ArrayList<receipemodel> list;

    public recyclerviewadapter(Context context, ArrayList<receipemodel> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @NotNull
    @Override
    public recyclerviewadapter.viewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.row,parent,false);
        //View view=LayoutInflater.from(context).inflate(R.layout.row,parent,false)
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull recyclerviewadapter.viewHolder holder, int position) {

        receipemodel model=list.get(position);
        holder.imageView.setImageResource(model.getImg());
        holder.textView.setText(model.getText());

    }

    @Override
    public int getItemCount() {
        return list.size();
    }
    public  class  viewHolder extends  RecyclerView.ViewHolder
    {
        ImageView imageView;
        TextView textView;


        public viewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            imageView=itemView.findViewById(R.id.imageView2);
            textView=itemView.findViewById(R.id.textView2);
        }
    }
}
