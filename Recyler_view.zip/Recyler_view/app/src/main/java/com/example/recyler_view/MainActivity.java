package com.example.recyler_view;

import Adapter.recyclerviewadapter;
import android.content.Context;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import model.receipemodel;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


  RecyclerView recyclerView;
  Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       recyclerView=findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ArrayList<receipemodel> list =new ArrayList<>();
        list.add(new receipemodel(R.drawable.img,"Burger"));

        list.add(new receipemodel(R.drawable.img_2,"kobi"));
        list.add(new receipemodel(R.drawable.img_3,"CheeseBurger"));

        list.add(new receipemodel(R.drawable.img_4,"Cake"));
        list.add(new receipemodel(R.drawable.img_5,"Pizza"));
        list.add(new receipemodel(R.drawable.img_6,"Pasta"));
        list.add(new receipemodel(R.drawable.img_7,"Chinese"));

        list.add(new receipemodel(R.drawable.img_2,"Burger"));

        recyclerviewadapter adapter =new recyclerviewadapter(this, list);
        recyclerView.setAdapter(adapter);
    }
}